    <?php wp_footer(); ?>
    
    <div class="lw-footer">
        <?php dynamic_sidebar('lw_footer_sidebar'); ?> 
    </div>

    <div class="lw-widget-hidden" style="display:none;">
        <?php dynamic_sidebar('lw_hidden_sidebar');?>
    </div>
</body>
</html>